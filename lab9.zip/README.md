# lab9
by Airton Neto

O que não foi implementado:
MergeSort, QuickSort
Fila

Como executar:
exemplo:    ./bin/prog_estatico
            ./bin/prog_dinamico